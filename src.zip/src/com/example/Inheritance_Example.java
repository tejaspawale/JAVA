package com.example;

public class Inheritance_Example {
 
	
	
	public void SBI_Bank() {
		System.out.println("id");
		System.out.println("Name");
		
	}
	
	
	public static void main(String[] args) {
    
		
		Inheritance_Example demo=new Inheritance_Example();
		   demo.SBI_Bank();
		
	
		
	

	}

}
