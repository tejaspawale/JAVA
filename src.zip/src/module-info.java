/**
 * 
 */
/**
 * @author hp
 *
 */
module Corejava {
}